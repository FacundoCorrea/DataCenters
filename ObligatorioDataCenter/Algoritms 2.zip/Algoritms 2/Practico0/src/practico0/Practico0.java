package practico0;

public class Practico0 {
    public static void main(String[] args) {
        int[][] hola = new int[3][3];
        hola[0][0] = 1;
        hola[0][2] = 3;
        hola[1][1] = 5;
        hola[2][0] = 7;
        hola[2][2] = 9;
        esPar(hola);
    }
    
    public static void esPar(int[][] matriz){
        int suma = 0;
        
        for(int i=0; i<matriz.length; i++){
            suma += matriz[i][i];
            if(matriz.length %2 == 1){
                suma += matriz[i][matriz.length-1-i];
            }
            else{
                suma += matriz[i][matriz.length-i];
            }
        }
        if(matriz.length %2 == 1){
            suma -= matriz[(matriz.length-1)/2][(matriz.length-1)/2];
        }
        else{
            suma -= matriz[matriz.length/2][matriz.length/2];
        }
        
        System.out.println("Suma: "+suma);
    }
    
}
