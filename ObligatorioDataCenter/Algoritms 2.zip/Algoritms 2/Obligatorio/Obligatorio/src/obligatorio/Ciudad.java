package obligatorio;

public class Ciudad extends Punto {
    
    public Ciudad(String nombre, double coordX, double coordY) {
        super(nombre, coordX, coordY);
    }
    
}
