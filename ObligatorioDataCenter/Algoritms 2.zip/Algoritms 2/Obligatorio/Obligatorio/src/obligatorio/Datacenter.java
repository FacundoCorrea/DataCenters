package obligatorio;

public class Datacenter extends Punto {
    private String empresa;
    private int capacidad;
    private int costoHora;
    private boolean utilizado;

    
    public Datacenter(String nombre, double coordX, double coordY) {
        super(nombre, coordX, coordY);
    }

    public Datacenter(String empresa, int capacidad, int costoHora, String nombre, double coordX, double coordY, boolean utilizado) {
        super(nombre, coordX, coordY);
        this.empresa = empresa;
        this.capacidad = capacidad;
        this.costoHora = costoHora;
        this.utilizado = utilizado;
    }
    
    public boolean isUtilizado() {
        return utilizado;
    }

    public void setUtilizado(boolean utilizado) {
        this.utilizado = utilizado;
    }
    
    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public int getCostoHora() {
        return costoHora;
    }

    public void setCostoHora(int costoHora) {
        this.costoHora = costoHora;
    }
    
    
    
}
