package obligatorio.Arboles;

import java.util.List;
import obligatorio.Empresa;
import obligatorio.Nodos.NodoEmpresa;

public class EmpresaAB {
    public static NodoEmpresa raiz;
    
    public static boolean insertar(Empresa empresa){
        NodoEmpresa nuevoNodo = new NodoEmpresa(empresa);
        boolean esta = false;
        
        if(raiz == null){
            raiz = nuevoNodo;
        }
        else{
            NodoEmpresa aux = raiz;
            NodoEmpresa ant = raiz;
            
            while(aux != null && !esta){
                ant = aux;
                if(aux.getEmpresa().getNombre().compareTo(empresa.getNombre()) < 0){
                    aux = aux.getDerecha();
                }
                else if(aux.getEmpresa().getNombre().compareTo(empresa.getNombre()) == 0){
                    esta = true;
                }
                else{
                    aux = aux.getIzquierda();
                }
            }
            
            if(ant.getEmpresa().getNombre().compareTo(empresa.getNombre()) < 0 && !esta){
                ant.setDerecha(nuevoNodo);
            }
            else if(!esta){
                ant.setIzquierda(nuevoNodo);
            }
        }
        return esta;
    }
    
    public static boolean existe(String nombre){
        NodoEmpresa aux = raiz;
        boolean existe = false;
        
        while(aux != null && !existe){
            if(aux.getEmpresa().getNombre().equals(nombre)){
                existe = true;
            }
            else{
                if(aux.getEmpresa().getNombre().compareTo(nombre) < 0){
                    aux = aux.getDerecha();
                }
                else{
                    aux = aux.getIzquierda();
                }
            }
        }
        return existe;
    }
    
    public static Empresa darEmpresaPorNombre(String nombre){
        NodoEmpresa aux = raiz;
        Empresa empresa = null;
        boolean parar = false;
        
        while(aux != null && !parar){
            if(aux.getEmpresa().getNombre().equals(nombre)){
                empresa = aux.getEmpresa();
                parar = true;
            }
            else{
                if(aux.getEmpresa().getNombre().compareTo(nombre) < 0){
                    aux = aux.getDerecha();
                }
                else{
                    aux = aux.getIzquierda();
                }
            }
        }
        return empresa;
    }
    
    public static List<Empresa> imprimirInOrden(List<Empresa> empresas, NodoEmpresa nodo){
        if(nodo != null){
            imprimirInOrden(empresas, nodo.getIzquierda());
            //System.out.println(nodo.getDato());
            empresas.add(nodo.getEmpresa());
            imprimirInOrden(empresas, nodo.getDerecha());
        }
        return empresas;
    }
    
}
