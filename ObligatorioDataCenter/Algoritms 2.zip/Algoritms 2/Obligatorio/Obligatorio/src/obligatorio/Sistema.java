package obligatorio;

import java.awt.Desktop;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import obligatorio.Arboles.EmpresaAB;
import obligatorio.Nodos.NodoTramo;
import obligatorio.Retorno.Resultado;

public class Sistema implements ISistema {

    private static Sistema s;
    private static Punto[] puntos;
    private NodoTramo[] tramos;
    private static final String[] colors = {"black", "brown", "green", "purple", "yellow", "blue", "gray", "orange", "red", "white"};
    private static final String[] colores = {"negro", "marron", "verde", "violeta", "amarillo", "azul", "gris", "naranja", "rojo", "blanco"};
    
    public static void main(String[] args)
    {
        s = darSistema();
               
        s.inicializarSistema(8);
        s.registrarCiudad("Punta", -34.194426, -55.249649);
        s.registrarCiudad("USA", 38.334773, -100.095771);
        s.registrarCiudad("Haiti", 19.006864, -72.099645);
        s.registrarCiudad("Londres", 51.513605, -0.200481);
        //s.mapaEstado();
        
        s.registrarEmpresa("Google", "SF", "USA", "info@google.com", "rojo");
        s.registrarEmpresa("Facebook", "CA", "USA", "news@facebook.com", "azul");
        s.registrarEmpresa("Twitter", "NY", "USA", "tweet@twitter.com", "blanco");
        s.registrarEmpresa("Amazon", "FL", "USA", "shop@amazon.com", "naranja");
        
        //String nombre, Double coordX, Double coordY, String empresa, int capacidadCPUenHoras, int costoCPUporHora
        s.registrarDC("googDC", 35.569888, 93.136090, "Google", 34, 768);
        s.registrarDC("fbDC", 35.569888, 93.136091, "Facebook", 0, 768);
        s.registrarDC("twDC", 38.334773, -100.095771, "Twitter", 37, 768);
        s.registrarDC("amzDC", 35.569888, 93.136092, "Amazon", 37, 768);
        
        for(Punto p : puntos){
            if(p != null){
                System.out.println(p.getNombre());
            }
        }
        
        /*Empresa google = EmpresaAB.darEmpresaPorNombre("Google");
        Empresa facebook = EmpresaAB.darEmpresaPorNombre("Facebook");
        Empresa twitter = EmpresaAB.darEmpresaPorNombre("Twitter");
        Empresa amazon = EmpresaAB.darEmpresaPorNombre("Amazon");
        
        if(google != null)
        System.out.println("Google: "+google.getEmail_contacto());
        
        if(facebook != null)
        System.out.println("Facebook: "+facebook.getEmail_contacto());
        
        if(twitter != null)
        System.out.println("Twitter: "+twitter.getEmail_contacto());
        
        if(amazon != null)
        System.out.println("Amazon: "+amazon.getEmail_contacto());*/
    }
    
    public static Sistema darSistema(){
        if(s == null){
            s = new Sistema();
        }
        return s;
    }
    
    @Override
    public Retorno inicializarSistema(int cantPuntos) {
        if(cantPuntos <= 0){
            return new Retorno(Resultado.ERROR_1);
        }
        else{
            puntos = new Punto[cantPuntos];
            tramos = new NodoTramo[cantPuntos];
            return new Retorno(Resultado.OK);
        }
    }

    @Override
    public Retorno destruirSistema() {
        puntos = null;
        return new Retorno(Resultado.OK);
    }

    @Override
    public Retorno registrarEmpresa(String nombre, String direccion, String pais, String email_contacto, String color) {
        if (email_contacto.contains("@") && email_contacto.contains(".")) {
            int pos = colorPosition(color);
            if(pos != -1){
                String colorPos = colors[pos];
                Empresa empresa = new Empresa(nombre, direccion, pais, email_contacto, colorPos);
                if(!EmpresaAB.insertar(empresa)){
                    return new Retorno(Resultado.OK);
                }
                else{
                    return new Retorno(Resultado.ERROR_2);
                    // Ya esta registrada una empresa con ese nombre
                }
            }
            else{
                // No se permite ese color. Mostrar mensaje
            }
        }
        return new Retorno(Resultado.ERROR_1);
    }

    @Override
    public Retorno registrarCiudad(String nombre, Double coordX, Double coordY) {
        if(isFull() || puntos == null){
            return new Retorno(Resultado.ERROR_1);
        }
        else if(alreadyAdded(coordX, coordY)){
            return new Retorno(Resultado.ERROR_2);
        }
        else{
            Punto ciudad = new Ciudad(nombre, coordX, coordY);
            int i = 0;
            boolean listo = false;
        
            while(i < puntos.length && !listo){
                if(puntos[i] == null){
                    puntos[i] = ciudad;
                    listo = true;
                }
                i++;
            }
            return new Retorno(Resultado.OK);
        }
    }

    @Override
    public Retorno registrarDC(String nombre, Double coordX, Double coordY, String empresa, int capacidadCPUenHoras, int costoCPUporHora) {
        if(isFull() || puntos == null){
            return new Retorno(Resultado.ERROR_1);
        }
        else if(capacidadCPUenHoras <= 0){
            return new Retorno(Resultado.ERROR_2);
        }
        else if(alreadyAdded(coordX, coordY)){
            return new Retorno(Resultado.ERROR_3);
        }
        else if(!EmpresaAB.existe(empresa)){
            return new Retorno(Resultado.ERROR_4);
        }
        else{
            Datacenter dc = new Datacenter(empresa, capacidadCPUenHoras, costoCPUporHora, nombre, coordX, coordY, false);
            
            int i = 0;
            int pos = 0;
            while(i < puntos.length){
                if(puntos[i] == null){
                    pos = i;
                    i = puntos.length;
                }
                i++;
            }
            
            puntos[pos] = dc;
            
            return new Retorno(Resultado.OK);
        }
    }

    @Override
    public Retorno registrarTramo(Double coordXi, Double coordYi, Double coordXf, Double coordYf, int peso) {
        if(peso <= 0){
            return new Retorno(Resultado.ERROR_1);
        }
        else if(!alreadyAdded(coordXi, coordYi) || !alreadyAdded(coordXf, coordYf)){
            return new Retorno(Resultado.ERROR_2);
        }
        else if(checkTramo(coordXi, coordYi, coordXf, coordYf) || checkTramo(coordXf, coordYf, coordXi, coordYi)){
            // Ya hay un tramo registrado
            return new Retorno(Resultado.ERROR_3);
        }
        else{
            int pos = puntoPosition(coordXi, coordYi);
            NodoTramo aux = tramos[pos];
            
            Punto punto = darPuntoPorCoords(coordXf, coordYf);
            
            while(aux.getSiguiente() != null){
                aux = aux.getSiguiente();
            }
            
            NodoTramo nuevoNodo = new NodoTramo();
            nuevoNodo.setPeso(peso);
            nuevoNodo.setPunto(punto);
            
            aux.setSiguiente(nuevoNodo);
            
            //------------Viceversa--------------
            
            int posVice = puntoPosition(coordXf, coordYf);
            NodoTramo auxVice = tramos[posVice];
            
            Punto puntoVice = darPuntoPorCoords(coordXi, coordYi);
            
            while(auxVice.getSiguiente() != null){
                auxVice = auxVice.getSiguiente();
            }
            
            NodoTramo nuevoNodoVice = new NodoTramo();
            nuevoNodoVice.setPeso(peso);
            nuevoNodoVice.setPunto(puntoVice);
            
            auxVice.setSiguiente(nuevoNodoVice);
            
            return new Retorno(Resultado.OK);
        }
    }

    @Override
    public Retorno eliminarTramo(Double coordXi, Double coordYi, Double coordXf, Double coordYf) {
        if(!alreadyAdded(coordXi, coordYi) || !alreadyAdded(coordXf, coordYf)){
            return new Retorno(Resultado.ERROR_1);
        }
        else if(!checkTramo(coordXi, coordYi, coordXf, coordYf) || !checkTramo(coordXf, coordYf, coordXi, coordYi)){
            // No hay tramos registrados
            return new Retorno(Resultado.ERROR_2);
        }
        else{
            int pos = puntoPosition(coordXi, coordYi);
            NodoTramo aux = tramos[pos];
            boolean seguir = true;

            while(aux.getSiguiente() != null && seguir){
                Punto punto = aux.getPunto();
                if(punto.getCoordX() == coordXf && punto.getCoordY() == coordYf){
                    NodoTramo auxAnterior = aux;
                    auxAnterior.setSiguiente(aux.getSiguiente());
                    seguir = false;
                }
                aux = aux.getSiguiente();
            }

            //------------Viceversa--------------

            int posVice = puntoPosition(coordXf, coordYf);
            NodoTramo auxVice = tramos[posVice];
            boolean seguirVice = true;

            while(auxVice.getSiguiente() != null && seguirVice){
                Punto punto = auxVice.getPunto();
                if(punto.getCoordX() == coordXi && punto.getCoordY() == coordYi){
                    NodoTramo auxAnterior = auxVice;
                    auxAnterior.setSiguiente(auxVice.getSiguiente());
                    seguirVice = false;
                }
                auxVice = auxVice.getSiguiente();
            }

            return new Retorno(Resultado.OK);
        }
    }

    @Override
    public Retorno eliminarPunto(Double coordX, Double coordY) {
        if(!alreadyAdded(coordX, coordY)){
            return new Retorno(Resultado.ERROR_1);
        }
        else{
            // Eliminar tramos
            int pos = puntoPosition(coordX, coordY);
            NodoTramo tramo = tramos[pos];
            
            while(tramo.getSiguiente() != null){
                Punto punto = tramo.getPunto();
                eliminarTramo(punto.getCoordX(), punto.getCoordY(), coordX, coordY);
                tramo = tramo.getSiguiente();
            }
            Punto punto = tramo.getPunto();
            eliminarTramo(punto.getCoordX(), punto.getCoordY(), coordX, coordY);

            tramos[pos] = null;
            
            // Eliminar punto
            int i = 0;
            
            while(i < puntos.length){
                if(puntos[i].getCoordX() == coordX && puntos[i].getCoordY() == coordY){
                    puntos[i] = null;
                    i = puntos.length;
                }
                i++;
            }
            return new Retorno(Resultado.OK);
        }
    }

    @Override
    public Retorno mapaEstado() {
        if(puntos != null){
            String defaultUrl = "http://maps.google.com/maps/api/staticmap?center=Golfo+de+Guinea&zoom=1&size=512x512&maptype=roadmap";
            String pipe = "%7C";    // |

            for(Punto p : puntos){
                if(p != null){
                    String color;
                    if(p instanceof Datacenter){
                        Datacenter dc = (Datacenter)p;
                        Empresa empresa = EmpresaAB.darEmpresaPorNombre(dc.getEmpresa());

                        color = String.format("%s", colors[colorPosition(empresa.getColor())]);
                    }
                    else{
                        color = String.format("%s", colors[4]);

                        // Preguntar si DC deben tener el color de la empresa. YA ESTA HECHO
                    }
                    String x = String.format("%.6f", p.getCoordX());
                    String y = String.format("%.6f",  p.getCoordY());

                    String result = "&markers=color:" + color + pipe + x + "," + y;

                    defaultUrl += result;
                }
            }

            try {
                Desktop.getDesktop().browse(new URL(defaultUrl).toURI());
            } catch (IOException | URISyntaxException ex) {
                Logger.getLogger(Sistema.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return new Retorno(Resultado.OK);
    }

    @Override
    public Retorno procesarInformacion(Double coordX, Double coordY, int esfuerzoCPUrequeridoEnHoras) {
        Datacenter dc = (Datacenter)darPuntoPorCoords(coordX, coordY);
        
        int costo = esfuerzoCPUrequeridoEnHoras * dc.getCostoHora();
        
        int pos = puntoPosition(coordX, coordY);
        
        NodoTramo tramo = tramos[pos];
        
        Datacenter dcFinal = dc;
        
        while(tramo.getSiguiente() != null){
            Punto punto = tramo.getPunto();
            Datacenter dcDif = (Datacenter)darPuntoPorCoords(punto.getCoordX(), punto.getCoordY());
            int costoTotal = (esfuerzoCPUrequeridoEnHoras * dcDif.getCostoHora()) + tramo.getPeso();
            
            if(costoTotal < costo){
                dcFinal = dcDif;
            }
            tramo = tramo.getSiguiente();
        }
        Punto punto = tramo.getPunto();
        Datacenter dcDif = (Datacenter)darPuntoPorCoords(punto.getCoordX(), punto.getCoordY());
        int costoTotal = (esfuerzoCPUrequeridoEnHoras * dcDif.getCostoHora()) + tramo.getPeso();

        if(costoTotal < costo){
            dcFinal = dcDif;
        }
        
        // Mostrar datos del dcFinal
        dcFinal.setUtilizado(true);
        
        
        return new Retorno(Resultado.OK);
    }

    @Override
    public Retorno listadoRedMinima() {
        // Checkear que esten todos los puntos y esten conectados
        return new Retorno(Resultado.NO_IMPLEMENTADA);
    }

    @Override
    public Retorno listadoEmpresas() {
        List<Empresa> empresas = EmpresaAB.imprimirInOrden(new ArrayList<>(), EmpresaAB.raiz);
        return new Retorno(Resultado.OK);
    }
    
    private boolean isFull(){
        boolean full = true;
        if(puntos != null){
            int i = 0;

            while(i < puntos.length && full){
                if(puntos[i] == null){
                    full = false;
                }
                i++;
            }
        }
        return full;
    }
    
    private boolean alreadyAdded(Double coordX, Double coordY){
        boolean already = false;
        int i = 0;
        
        if(puntos == null){
            already = true;
        }
        else{
            while(i < puntos.length && !already){
                if(puntos[i] != null && puntos[i].getCoordX() == coordX && puntos[i].getCoordY() == coordY){
                    already = true;
                }
                i++;
            }
        }
        return already;
    }
    
    private boolean checkTramo(Double coordXi, Double coordYi, Double coordXf, Double coordYf){
        boolean esta = false;
        
        int pos = puntoPosition(coordXi, coordYi);
        
        NodoTramo tramo = tramos[pos];
        
        while(tramo.getSiguiente() != null && !esta){
            Punto punto = tramo.getPunto();
            if(punto.getCoordX() == coordXf && punto.getCoordY() == coordYf){
                esta = true;
            }
            tramo = tramo.getSiguiente();
        }
        if(!esta){
            Punto punto = tramo.getPunto();
            if(punto.getCoordX() == coordXf && punto.getCoordY() == coordYf){
                esta = true;
            }
        }
        return esta;
    }
    
    private Punto darPuntoPorCoords(Double coordX, Double coordY){
        int i = 0;
        Punto punto = null;
        boolean seguir = true;
        
        while(i < puntos.length && seguir){
            if(puntos[i].getCoordX() == coordX && puntos[i].getCoordY() == coordY){
                punto = puntos[i];
                seguir = false;
                i = puntos.length;
            }
            i++;
        }
        return punto;
    }
    
    private int puntoPosition(Double coordX, Double coordY){
        int i = 0;
        int pos = 0;
        
        while(i < puntos.length){
            if(puntos[i].getCoordX() == coordX && puntos[i].getCoordY() == coordY){
                pos = i;
                i = puntos.length;
            }
            i++;
        }
        return pos;
    }
    
    private int colorPosition(String color){
        int i = 0;
        int pos = -1;
        
        while(i < colores.length){
            if(colores[i].equals(color)){
                pos = i;
                i = colores.length;
            }
            i++;
        }
        return pos;
    }
    
}
