package obligatorio;

public class Tramo {
    private double coordXi;
    private double coordYi;
    private double coordXf;
    private double coordYf;

    public Tramo(double coordXi, double coordYi, double coordXf, double coordYf) {
        this.coordXi = coordXi;
        this.coordYi = coordYi;
        this.coordXf = coordXf;
        this.coordYf = coordYf;
    }
    
    public double getCoordXi() {
        return coordXi;
    }

    public void setCoordXi(double coordXi) {
        this.coordXi = coordXi;
    }

    public double getCoordYi() {
        return coordYi;
    }

    public void setCoordYi(double coordYi) {
        this.coordYi = coordYi;
    }

    public double getCoordXf() {
        return coordXf;
    }

    public void setCoordXf(double coordXf) {
        this.coordXf = coordXf;
    }

    public double getCoordYf() {
        return coordYf;
    }

    public void setCoordYf(double coordYf) {
        this.coordYf = coordYf;
    }
}
