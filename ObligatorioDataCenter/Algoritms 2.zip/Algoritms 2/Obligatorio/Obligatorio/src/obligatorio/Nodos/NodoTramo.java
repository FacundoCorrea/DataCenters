package obligatorio.Nodos;

import obligatorio.Punto;

public class NodoTramo {
    private Punto punto;
    private int peso;
    private NodoTramo siguiente;

    public Punto getPunto() {
        return punto;
    }

    public void setPunto(Punto punto) {
        this.punto = punto;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public NodoTramo getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoTramo siguiente) {
        this.siguiente = siguiente;
    }
    
    
}
