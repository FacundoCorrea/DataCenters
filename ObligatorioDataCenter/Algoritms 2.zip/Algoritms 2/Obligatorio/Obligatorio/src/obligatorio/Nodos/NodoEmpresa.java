package obligatorio.Nodos;

import obligatorio.Empresa;

public class NodoEmpresa {
    Empresa empresa;
    NodoEmpresa izquierda;
    NodoEmpresa derecha;

    public NodoEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }
    
    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public NodoEmpresa getIzquierda() {
        return izquierda;
    }

    public void setIzquierda(NodoEmpresa izquierda) {
        this.izquierda = izquierda;
    }

    public NodoEmpresa getDerecha() {
        return derecha;
    }

    public void setDerecha(NodoEmpresa derecha) {
        this.derecha = derecha;
    }
    
}
